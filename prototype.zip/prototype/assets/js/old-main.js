document.addEventListener('DOMContentLoaded', () => {
   
    // For Nav color change
    const nav = document.querySelector('nav');
    const readySection = document.getElementById('ready');

    window.addEventListener('scroll', () => {
        const rect = readySection.getBoundingClientRect();
        if (rect.top <= 0) {
            nav.classList.add('dark-nav');
        } else {
            nav.classList.remove('dark-nav');
        }
    });


    // For Home section animations
    const homeContainer = document.querySelector('.home-content');
    const homeH1 = document.querySelector('.home-h1');
    const homeP = document.querySelector('.home-p');
    const homeH3 = document.querySelector('.home-h3');

    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0
    };

    const observerCallback = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Start h1 animation immediately
                homeH1.classList.add('start');

                // Listen for the end of h1 animation to start p animation
                homeH1.addEventListener('animationend', () => {
                    homeP.classList.add('start');
                }, { once: true });

                // Listen for the end of p animation to start a animation
                homeP.addEventListener('animationend', () => {
                    homeH3.classList.add('start');
                }, { once: true });

                // Stop observing after the animations have been triggered
                observer.unobserve(homeContainer);
            }
        });
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);
    observer.observe(homeContainer);
});