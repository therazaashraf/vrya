document.addEventListener('DOMContentLoaded', () => {
   
    // For Nav color change
    const nav = document.querySelector('nav');
    const readySection = document.getElementById('ready');

    window.addEventListener('scroll', () => {
        const rect = readySection.getBoundingClientRect();
        if (rect.top <= 0) {
            nav.classList.add('dark-nav');
        } else {
            nav.classList.remove('dark-nav');
        }
    });


    // For animations
    const containers = document.querySelectorAll('.anim-cont');

    const observerOptions = {
        root: null,
        rootMargin: '-40% 0px',
        threshold: 0
    };

    const observerCallback = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const elements = entry.target.children;

                Array.from(elements).forEach((el, index) => {
                    const animationName = el.dataset.animation;

                    setTimeout(() => {
                        el.classList.add(`start-${animationName}`);
                    }, index * 1000); // Delay each animation by 1 seconds
                });

                observer.unobserve(entry.target);
            }
        });
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);

    containers.forEach(container => {
        observer.observe(container);
    });



   
});